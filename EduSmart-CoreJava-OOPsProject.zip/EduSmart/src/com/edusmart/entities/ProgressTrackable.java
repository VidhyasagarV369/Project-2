package com.edusmart.entities;

public interface ProgressTrackable {
    void trackProgress();
}
