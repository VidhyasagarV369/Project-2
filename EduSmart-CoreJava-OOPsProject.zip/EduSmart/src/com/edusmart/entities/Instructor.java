package com.edusmart.entities;

public class Instructor extends User {
    private Course course1;
    private Course course2;

    public Instructor(String name, String email, String userId) {
        super(name, email, userId);
        displayWelcome();
    }

    public void createCourse(Course course) {
        if (course1 == null) {
            course1 = course;
            System.out.println(getName() + " created course: " + course.getTitle());
        } else if (course2 == null) {
            course2 = course;
            System.out.println(getName() + " created course: " + course.getTitle());
        } else {
            System.out.println(getName() + " cannot create more courses (limit reached)");
        }
    }

    @Override
    public void viewProfile() {
        System.out.println("\nInstructor Profile:");
        System.out.println("Name: " + getName());
        System.out.println("Email: " + getEmail());
        System.out.println("Courses Teaching: " + 
                         (course1 != null ? course1.getTitle() : "None") + ", " +
                         (course2 != null ? course2.getTitle() : "None"));
    }
}
