package com.edusmart.entities;

public class Course {
    private String title;
    private int duration;
    public final int maxStudents;

    public Course(String title, int duration, int maxStudents) {
        this.title = title;
        this.duration = duration;
        this.maxStudents = maxStudents;
    }

    public String getTitle() { return title; }

    public void showCourseDetails() {
        System.out.println("\nCourse Details:");
        System.out.println("Title: " + title);
        System.out.println("Duration: " + duration + " hours");
        System.out.println("Max Students: " + maxStudents);
    }
}
