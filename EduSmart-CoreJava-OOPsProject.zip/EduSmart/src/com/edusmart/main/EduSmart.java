package com.edusmart.main;

import com.edusmart.entities.*;

public class EduSmart {
    public static void main(String[] args) {
        // Initialize system with sample data
        Admin admin = new Admin("System Admin", "admin@edusmart.com", "ADM001");
        
        Instructor profSagar = new Instructor("Prof. Sagar", "sagar@edusmart.com", "INS001");
        Instructor profGupta = new Instructor("Prof. Gupta", "gupta@edusmart.com", "INS002");
        
        Student vidhya = new Student("Student Vidhya", "vidhya@edusmart.com", "STU001");
        Student rahul = new Student("Student Rahul", "rahul@edusmart.com", "STU002");
        
        Course mathematics = new Course("Mathematics", 60, 30);
        Course computerScience = new Course("Computer Science ", 45, 25);
        Course physics = new Course("ActurialScience", 50, 20);

        // System operations
        System.out.println("\n=== EDU SMART LMS ===\n");
        System.out.println("1. COURSE CREATION");
        profSagar.createCourse(mathematics);
        profGupta.createCourse(computerScience);
        profGupta.createCourse(physics);
        
        System.out.println("\n2. STUDENT ENROLLMENT");
        vidhya.enrollCourse(mathematics);
        vidhya.enrollCourse(computerScience);
        rahul.enrollCourse(mathematics);
        rahul.enrollCourse(physics);

        System.out.println("\n3. USER PROFILES");
        vidhya.viewProfile();
        rahul.viewProfile();
        profSagar.viewProfile();
        profGupta.viewProfile();
        admin.viewProfile();

        System.out.println("\n4. PROGRESS TRACKING");
        vidhya.trackProgress();
        rahul.trackProgress();

        System.out.println("\n5. ADMIN ACTIONS");
        admin.removeUser(rahul);

        System.out.println("\n6. COURSE DETAILS");
        mathematics.showCourseDetails();
        computerScience.showCourseDetails();
        physics.showCourseDetails();

        System.out.println("\n=== SYSTEM SUMMARY ===");
        System.out.println("Total Students: 2");
        System.out.println("Total Instructors: 2");
        System.out.println("Total Courses: 3");
        System.out.println("\nSystem operations completed successfully!");
    }
}
