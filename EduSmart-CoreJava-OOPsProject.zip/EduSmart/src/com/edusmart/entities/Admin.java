package com.edusmart.entities;

public class Admin extends User {
    public Admin(String name, String email, String userId) {
        super(name, email, userId);
        displayWelcome();
    }

    public void removeUser(User user) {
        System.out.println("Admin action: Removed user - " + user.getName());
    }

    @Override
    public void viewProfile() {
        System.out.println("\nAdmin Profile:");
        System.out.println("Name: " + getName());
        System.out.println("Email: " + getEmail());
        System.out.println("Role: System Administrator");
    }
}
