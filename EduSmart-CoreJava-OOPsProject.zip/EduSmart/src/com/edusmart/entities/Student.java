package com.edusmart.entities;

import java.util.HashMap;
import java.util.Map;

public class Student extends User implements ProgressTrackable {
    private Map<Course, Integer> enrolledCourses = new HashMap<>();

    public Student(String name, String email, String userId) {
        super(name, email, userId);
        displayWelcome();
    }

    public void enrollCourse(Course course) {
        if (enrolledCourses.size() < 2) {
            enrolledCourses.put(course, 0);
            System.out.println(getName() + " enrolled in " + course.getTitle());
        } else {
            System.out.println(getName() + " cannot enroll in more courses (limit reached)");
        }
    }

    public boolean isEnrolled(Course course) {
        return enrolledCourses.containsKey(course);
    }

    @Override
    public void trackProgress() {
        System.out.println("\n" + getName() + "'s Progress:");
        enrolledCourses.forEach((course, progress) -> {
            System.out.println("- " + course.getTitle() + ": " + progress + "% complete");
        });
    }

    @Override
    public void viewProfile() {
        System.out.println("\nStudent Profile:");
        System.out.println("Name: " + getName());
        System.out.println("Email: " + getEmail());
        System.out.println("Enrolled in: " + enrolledCourses.size() + " courses");
    }
}
